define({
  "name": "Zencart Mobile API",
  "version": "0.1.0",
  "description": "API документация проекта Zencart",
  "title": "Zencart Mobile API",
  "url": "site_url/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-05-02T19:13:02.872Z",
    "url": "http://apidocjs.com",
    "version": "0.17.5"
  }
});
